//
//  Objects.m
//  XML_Week4
//
//  Created by Annis Dan on 7/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Objects.h"
#import "ViewController.h"
#import "XMLParser.h"
#import "XMLDetailViewController.h"
#import "XMLWebViewController.h"

@implementation Objects

@synthesize content = _content;
@synthesize dateCreated = _dateCreated;
@synthesize img = _img;
@synthesize city = _city;
@synthesize full = _full;

@end
