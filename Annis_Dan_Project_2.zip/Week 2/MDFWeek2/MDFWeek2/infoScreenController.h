//
//  infoScreenController.h
//  MDFWeek2
//
//  Created by Annis Dan on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface infoScreenController : UIViewController

@end
