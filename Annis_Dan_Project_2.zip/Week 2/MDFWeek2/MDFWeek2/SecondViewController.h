//
//  SecondViewController.h
//  MDFWeek2
//
//  Created by Annis Dan on 7/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@end
